import React, {useEffect, useState} from 'react';
import fireconf from '../../firebaseConf';
import { Text, View, Image, ScrollView, TouchableOpacity } from 'react-native';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import { createMaterialBottomTabNavigator } from '@react-navigation/material-bottom-tabs';
import { colors } from '../../utils';
import { aula, kelas, meeting, music, profile } from '../../assets';
import { Button } from '../../components';

const Tab = createMaterialBottomTabNavigator();

const Beranda = ({ navigation }) => {
    const [user, setUser] = useState('');
    
    useEffect(() => {
      const { currentUser } = fireconf.auth()
      setUser(currentUser)
    }, [])

    const handleGoTo = screen => {
        navigation.navigate(screen);
  }
  
  const onLogout = () => {
    fireconf.auth().signOut()
    navigation.navigate('WellcomeAuth')
  }
    return (
        <ScrollView showsHorizontalScrollIndicator={false}>
            <View style={styles.content}>
          <Text style={{ color: '#fff', textAlign: 'center', fontSize: 24, maxWidth: 250 }}>Selamat Datang { user.email }</Text>
              <TouchableOpacity onPress={onLogout}>
                <Text style={{ textAlign: 'center' }}>Logout</Text>
              </TouchableOpacity>
            </View>

            <View style={styles.cardsWrapper}>
              <Text style={{color: '#333'}}>List Ruangan</Text>
              <View style={styles.card}>
                <View style={styles.cardImgWrapper}>
                    <Image source={kelas} resizeMode="cover" style={styles.cardImg} />
                </View>
                <View style={styles.cardInfo}>
                    <Text style={styles.cardTitle}>Ruang Kelas 3 A</Text>
                    <Button type="bookingbtn" name="booking" onPress={() => handleGoTo('Booking')} />
                </View>
              </View>
            </View>

            <View style={styles.cardsWrapper}>
              <View style={styles.card}>
                <View style={styles.cardImgWrapper}>
                    <Image source={aula} resizeMode="cover" style={styles.cardImg} />
                </View>
                <View style={styles.cardInfo}>
                    <Text style={styles.cardTitle}>Ruang Aula Lt 4</Text>
                    <Button type="bookingbtn" name="booking" onPress={() => handleGoTo('Booking')} />
                </View>
              </View>
            </View>

            <View style={styles.cardsWrapper}>
              <View style={styles.card}>
                <View style={styles.cardImgWrapper}>
                    <Image source={meeting} resizeMode="cover" style={styles.cardImg} />
                </View>
                <View style={styles.cardInfo}>
                    <Text style={styles.cardTitle}>Ruang Meeting</Text>
                    <Button type="bookingbtn" name="booking" onPress={() => handleGoTo('Booking')} />
                </View>
              </View>
            </View>

            <View style={styles.cardsWrapper}>
              <View style={styles.card}>
                <View style={styles.cardImgWrapper}>
                    <Image source={music} resizeMode="cover" style={styles.cardImg} />
                </View>
                <View style={styles.cardInfo}>
                    <Text style={styles.cardTitle}>Studio Music</Text>
                    <Button type="bookingbtn" name="booking" onPress={() => handleGoTo('Booking')} />
                </View>
              </View>
            </View>

        </ScrollView>
    )
}

const Profile = () => {
  return (
    <ScrollView>
        <View style={{backgroundColor: colors.default, borderBottomLeftRadius: 28, borderBottomRightRadius: 28, justifyContent: 'center', alignItems: 'center', padding: 40}}>
          <Image source={require("../../assets/illustrations/foto.png")} style={{width: 200, height: 200, borderRadius: 100}} />
          <Text style={{fontSize: 18, fontWeight: 'bold', color: '#fff', marginTop: 18}}>Welcome Back!</Text>
          <Text style={{fontSize: 25, fontWeight: 'bold', color: '#fff', marginTop: 12}}>Irvan Mahendra</Text>
        </View>

      <View>
        <Image source={require("../../assets/illustrations/pin.png")} style={{width: 30, height: 30, borderRadius: 100, marginTop: 20, marginBottom:10, marginLeft: 10}}/>
      </View>

      <Text style={styles.labelitem}>
        Alamat
      </Text>
      <Text style={styles.sublabelitem}>
        Jl. Tukad Badung No. 01 Denpasar, Bali
      </Text>

      <View>
        <Image source={require("../../assets/illustrations/phone.png")} style={{width: 30, height: 30, borderRadius: 100, marginTop: 20, marginBottom:10, marginLeft: 10}}/>
      </View>

      <Text style={styles.labelitem}>
        Phone
      </Text>
      <Text style={styles.sublabelitem}>
        +6281-234-567
      </Text>

      <View>
        <Image source={require("../../assets/illustrations/gmail.png")} style={{width: 30, height: 30, borderRadius: 100, marginTop: 20, marginBottom:10, marginLeft: 10}}/>
      </View>

      <Text style={styles.labelitem}>
        E-mail
      </Text>
      <Text style={styles.sublabelitem}>
        admin@quto.com
      </Text>
   

    



    </ScrollView>
    
  )
}

function Main() {
  return (
    <Tab.Navigator>
      <Tab.Screen name="Profile" component={Profile}
      options={{
        tabBarLabel: 'Profile',
        tabBarIcon: ({ color }) => (
          <MaterialCommunityIcons name="account" color={color} size={26} />
        ),
      }}/>

    </Tab.Navigator>
  );
}

const styles = {
    cardsWrapper: {
      marginTop: 20,
      width: '90%',
      alignSelf: 'center',
    },
    card: {
      height: 100,
      marginVertical: 10,
      flexDirection: 'row',
      shadowColor: '#999',
      shadowOffset: {width: 0, height: 1},
      shadowOpacity: 0.8,
      shadowRadius: 2,
      elevation: 5,
    },
    cardImgWrapper: {
      flex: 1,
    },
    cardImg: {
      height: '100%',
      width: '100%',
      alignSelf: 'center',
      borderRadius: 8,
      borderBottomRightRadius: 0,
      borderTopRightRadius: 0,
    },
    cardInfo: {
      flex: 2,
      padding: 12,
      borderColor: '#ccc',
      borderWidth: 1,
      borderLeftWidth: 0,
      borderBottomRightRadius: 8,
      borderTopRightRadius: 8,
      backgroundColor: '#fff',
    },
    cardTitle: {
      fontWeight: 'bold',
      fontSize: 18,
      color: colors.dark
    },
    cardDetails: {
      fontSize: 12,
      color: '#444',
    },
    content: {
        backgroundColor: colors.default,
        paddingVertical: 60,
        height: 200,
        justifyContent: 'center', alignItems: 'center'
    },
    wrapper: {
        backgroundColor: '#f1f1f1',
        height: '100%',
        padding: 23
    },
    illustration: {
        width: 115, 
        height: 115,
        borderRadius: 8,
        flexDirection: 'row'
    },

    labelitem:{
      marginTop: -45,
      marginLeft: 60,
      fontSize: 18, 
    },

    sublabelitem: {
      marginTop: 4,
      marginLeft: 60,
      fontSize: 16
    }
}

export default Main;