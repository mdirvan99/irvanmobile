import Splash from './Splash';
import Login from './Login';
import Register from './Register';
import WellcomeAuth from './WellcomeAuth';
import Main from './Main';
import Booking from './Booking';

export {Splash, Login, Register, WellcomeAuth, Main, Booking};