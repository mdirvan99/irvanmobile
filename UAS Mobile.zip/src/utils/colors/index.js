export const colors = {
    default: '#00B0FF',
    dark: '#333',
};